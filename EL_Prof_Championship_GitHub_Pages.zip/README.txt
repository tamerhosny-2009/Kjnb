ارفع index.html ومجلد images كما هما داخل نفس Repository على GitHub.
